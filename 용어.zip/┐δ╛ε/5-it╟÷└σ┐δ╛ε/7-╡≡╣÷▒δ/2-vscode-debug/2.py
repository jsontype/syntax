a = 10
b = 20
c = a + b
print("결과" + str(c))
print("결과" + str(c))
print("결과" + str(c))
