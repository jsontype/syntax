import React from 'react'

export default function Title() {
  return (
    <div>뉴스 앱</div>
  )
}
